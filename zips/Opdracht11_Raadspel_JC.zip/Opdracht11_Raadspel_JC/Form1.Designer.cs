﻿namespace Opdracht11_Raadspel_JC
{
    partial class FrmRaadspel
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRaadspel));
            this.TxtNum = new System.Windows.Forms.TextBox();
            this.TxtResultaat = new System.Windows.Forms.TextBox();
            this.TxtBeurten = new System.Windows.Forms.TextBox();
            this.BtnEvalueer = new System.Windows.Forms.Button();
            this.BtnNieuw = new System.Windows.Forms.Button();
            this.BtnEinde = new System.Windows.Forms.Button();
            this.LblVraag = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TxtNum
            // 
            this.TxtNum.Location = new System.Drawing.Point(241, 44);
            this.TxtNum.Name = "TxtNum";
            this.TxtNum.Size = new System.Drawing.Size(33, 22);
            this.TxtNum.TabIndex = 1;
            this.TxtNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TxtResultaat
            // 
            this.TxtResultaat.Enabled = false;
            this.TxtResultaat.Location = new System.Drawing.Point(29, 100);
            this.TxtResultaat.Name = "TxtResultaat";
            this.TxtResultaat.Size = new System.Drawing.Size(245, 22);
            this.TxtResultaat.TabIndex = 2;
            // 
            // TxtBeurten
            // 
            this.TxtBeurten.Enabled = false;
            this.TxtBeurten.Location = new System.Drawing.Point(29, 135);
            this.TxtBeurten.Name = "TxtBeurten";
            this.TxtBeurten.Size = new System.Drawing.Size(245, 22);
            this.TxtBeurten.TabIndex = 3;
            // 
            // BtnEvalueer
            // 
            this.BtnEvalueer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnEvalueer.Location = new System.Drawing.Point(312, 50);
            this.BtnEvalueer.Name = "BtnEvalueer";
            this.BtnEvalueer.Size = new System.Drawing.Size(90, 23);
            this.BtnEvalueer.TabIndex = 4;
            this.BtnEvalueer.Text = "&Evalueer";
            this.BtnEvalueer.UseVisualStyleBackColor = true;
            this.BtnEvalueer.Click += new System.EventHandler(this.BtnEvalueer_Click);
            // 
            // BtnNieuw
            // 
            this.BtnNieuw.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnNieuw.Location = new System.Drawing.Point(312, 90);
            this.BtnNieuw.Name = "BtnNieuw";
            this.BtnNieuw.Size = new System.Drawing.Size(90, 23);
            this.BtnNieuw.TabIndex = 5;
            this.BtnNieuw.Text = "&Nieuw spel";
            this.BtnNieuw.UseVisualStyleBackColor = true;
            this.BtnNieuw.Click += new System.EventHandler(this.BtnNieuw_Click);
            // 
            // BtnEinde
            // 
            this.BtnEinde.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnEinde.Location = new System.Drawing.Point(312, 130);
            this.BtnEinde.Name = "BtnEinde";
            this.BtnEinde.Size = new System.Drawing.Size(90, 23);
            this.BtnEinde.TabIndex = 6;
            this.BtnEinde.Text = "&Einde";
            this.BtnEinde.UseVisualStyleBackColor = true;
            this.BtnEinde.Click += new System.EventHandler(this.BtnEinde_Click);
            // 
            // LblVraag
            // 
            this.LblVraag.AutoSize = true;
            this.LblVraag.Location = new System.Drawing.Point(29, 50);
            this.LblVraag.Name = "LblVraag";
            this.LblVraag.Size = new System.Drawing.Size(192, 16);
            this.LblVraag.TabIndex = 7;
            this.LblVraag.Text = "Geef een getal van 1 t.e.m. 100:";
            // 
            // FrmRaadspel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 194);
            this.Controls.Add(this.LblVraag);
            this.Controls.Add(this.BtnEinde);
            this.Controls.Add(this.BtnNieuw);
            this.Controls.Add(this.BtnEvalueer);
            this.Controls.Add(this.TxtBeurten);
            this.Controls.Add(this.TxtResultaat);
            this.Controls.Add(this.TxtNum);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmRaadspel";
            this.Text = "Raadspel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private TextBox TxtNum;
        private TextBox TxtResultaat;
        private TextBox TxtBeurten;
        private Button BtnEvalueer;
        private Button BtnNieuw;
        private Button BtnEinde;
        private Label LblVraag;
    }
}