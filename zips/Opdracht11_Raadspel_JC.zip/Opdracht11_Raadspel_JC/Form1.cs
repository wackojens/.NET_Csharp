namespace Opdracht11_Raadspel_JC
{
    public partial class FrmRaadspel : Form
    {
        public FrmRaadspel()
        {
            InitializeComponent();
        }

        Random rndm;
        int randNum = 0, teller = 0;

        private void BtnEinde_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnEvalueer_Click(object sender, EventArgs e)
        {
            int gok;

            if (randNum == 0)
            {
                rndm = new Random();
                randNum = rndm.Next(1, 101);
            }

            try
            {
                gok = Convert.ToInt16(TxtNum.Text);
            }
            catch
            {
                MessageBox.Show("Geef een geheel getal van 1 t.e.m. 100 in");
                TxtNum.Clear();
                TxtNum.Focus();
                return;
            }

            if (gok < randNum)
            {
                TxtResultaat.Text = ("De te zoeken waarde is hoger");
                teller += 1;
                TxtBeurten.Text = teller.ToString();
            }
            else if (gok > randNum)
            {
                TxtResultaat.Text = ("De te zoeken waarde is lager");
                teller += 1;
                TxtBeurten.Text = teller.ToString();
            }
            else if (gok == randNum)
            {
                TxtResultaat.Text = ("Proficiat! U heeft het getal geraden");
                teller += 1;
                TxtBeurten.Text = ("Aantal keren geraden: " + teller);
            }
        }

        private void BtnNieuw_Click(object sender, EventArgs e)
        {
            rndm = new Random();
            randNum = rndm.Next(1,101);
            teller = 0;
            TxtResultaat.Clear();
            TxtBeurten.Clear();
            TxtNum.Clear();
            TxtNum.Focus();
        }
    }
}